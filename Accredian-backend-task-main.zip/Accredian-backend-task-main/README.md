# Accredian-backend-task
Accredian-backend-task.
<h2>Use dotenv</h2> 
Enviroment Variables <br>
PORT=8080 <br>
JWT_SECRET=iuasduiiiiiiiiiiiiiiiii
<h3>DB config data is not in dotenv just to make it easy to  understand i hardcoded it else it will be in dotenv</h3>
